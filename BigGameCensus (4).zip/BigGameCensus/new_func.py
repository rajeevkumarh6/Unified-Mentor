def new_func(app):
    app.run(debug=True)