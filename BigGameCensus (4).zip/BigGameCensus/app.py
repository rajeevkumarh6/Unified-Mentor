from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import io
import base64

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Global variables to store the datasets
places_population = None
states_population = None
big_game_census = None

def load_datasets():
    global places_population, states_population, big_game_census
    try:
        places_population = pd.read_excel(os.path.join(app.config['UPLOAD_FOLDER'], 'All Places Census 2016 Population Estimates.xlsx'))
        states_population = pd.read_excel(os.path.join(app.config['UPLOAD_FOLDER'], 'All states Census 2017 Population Estimates.xlsx'))
        big_game_census = pd.read_excel(os.path.join(app.config['UPLOAD_FOLDER'], 'Big Game Census data.xlsx'))
        print("Datasets loaded successfully")
    except Exception as e:
        print(f"Error loading datasets: {e}")

def plot_to_img(plt):
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return f'data:image/png;base64,{plot_url}'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_files():
    if request.method == 'POST':
        places_file = request.files['places_population']
        states_file = request.files['states_population']
        big_game_file = request.files['big_game_census']

        try:
            places_file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'All Places Census 2016 Population Estimates.xlsx'))
            states_file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'All states Census 2017 Population Estimates.xlsx'))
            big_game_file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'Big Game Census data.xlsx'))
            load_datasets()
            return redirect(url_for('results'))
        except Exception as e:
            print(f"Error saving files: {e}")
            return "Error uploading files", 500

    return render_template('upload.html')

@app.route('/results')
def results():
    if big_game_census is None or states_population is None or places_population is None:
        return 'Data not uploaded', 400

    return render_template('results.html')

@app.route('/api/players-by-state')
def players_by_state():
    if big_game_census is None:
        return jsonify({'error': 'Data not uploaded'}), 400
    players_by_state_data = big_game_census['Player Birth State'].value_counts()
    return players_by_state_data.to_dict()

@app.route('/api/players-visualization')
def players_visualization():
    if big_game_census is None:
        return 'Data not uploaded', 400
    players_by_state_data = big_game_census['Player Birth State'].value_counts()

    plt.figure(figsize=(12, 8))
    sns.barplot(x=players_by_state_data.index, y=players_by_state_data.values, palette='viridis')
    plt.xticks(rotation=90)
    plt.title('Number of Players by Birth State')
    plt.xlabel('State')
    plt.ylabel('Number of Players')
    players_by_state_img = plot_to_img(plt)

    return players_by_state_img

@app.route('/api/top-states-population')
def top_states_population():
    if big_game_census is None or states_population is None:
        return jsonify({'error': 'Data not uploaded'}), 400
    players_by_state_data = big_game_census['Player Birth State'].value_counts()
    top_states = players_by_state_data.head(10).index
    top_states_population_data = states_population[states_population['Geography Name'].isin(top_states)]
    return top_states_population_data.to_dict(orient='records')

@app.route('/api/top-states-visualization')
def top_states_visualization():
    if big_game_census is None or states_population is None:
        return 'Data not uploaded', 400
    players_by_state_data = big_game_census['Player Birth State'].value_counts()
    top_states = players_by_state_data.head(10).index
    top_states_population_data = states_population[states_population['Geography Name'].isin(top_states)]

    plt.figure(figsize=(12, 8))
    sns.barplot(x='Geography Name', y='Population Estimate (as of July 1) - 2017', data=top_states_population_data, palette='coolwarm')
    plt.xticks(rotation=90)
    plt.title('Population of States with the Highest Number of Players')
    plt.xlabel('State')
    plt.ylabel('Population Estimate (2017)')
    top_states_population_img = plot_to_img(plt)

    return top_states_population_img

@app.route('/fun-facts')
def fun_facts():
    if big_game_census is None or states_population is None:
        return 'Data not uploaded', 400
    players_by_state_data = big_game_census['Player Birth State'].value_counts()
    most_players_state = players_by_state_data.idxmax()
    most_players_count = players_by_state_data.max()
    most_populous_state = states_population.loc[states_population['Population Estimate (as of July 1) - 2017'].idxmax()]

    fun_facts = {
        'most_players_state': most_players_state,
        'most_players_count': most_players_count,
        'most_populous_state': most_populous_state['Geography Name'],
        'most_populous_population': most_populous_state['Population Estimate (as of July 1) - 2017']
    }

    return fun_facts

if __name__ == '__main__':
    app.run(debug=True)
